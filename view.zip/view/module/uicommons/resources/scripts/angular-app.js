angular.module('uicommons.filters', []);

angular.module('uicommons', [ 'uicommons.filters' ]);