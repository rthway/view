
// our custom Creole localizations for the ng-grid element
window.ngGrid.i18n['ht'] = {
    ngTotalItemsLabel: "Total Atik:",
    ngPageSizeLabel: "Ranje Pa Paj:"

};