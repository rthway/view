if (!djConfig)
	var djConfig = {isDebug: false, debugAtAllCosts: false};