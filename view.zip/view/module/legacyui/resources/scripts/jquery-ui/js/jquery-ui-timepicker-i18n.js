
jQuery(function($){
//	$j.timepicker.regional['es'] = {//ToDo: Translate
//        currentText: 'Now',
//		closeText: 'Done',
//		ampm: false,
//		timeFormat: 'hh:mm tt',
//		timeOnlyTitle: 'Choose Time',
//		timeText: 'Time',
//		hourText: 'Hour',
//		minuteText: 'Minute',
//		secondText: 'Second'};
	$j.timepicker.regional['en-GB'] = {
        currentText: 'Now',
		closeText: 'Done',
		ampm: false,
		timeFormat: 'hh:mm',
		timeOnlyTitle: 'Choose Time',
		timeText: 'Time',
		hourText: 'Hour',
		minuteText: 'Minute',
		secondText: 'Second'};
//	$j.timepicker.regional['fr'] = {//ToDo: Translate
//		currentText: 'Now',
//		closeText: 'Done',
//		ampm: false,
//		timeFormat: 'hh:mm tt',
//		timeOnlyTitle: 'Choose Time',
//		timeText: 'Time',
//		hourText: 'Hour',
//		minuteText: 'Minute',
//		secondText: 'Second'};
//	$j.timepicker.regional['it'] = {//ToDo: Translate
//        currentText: 'Now',
//		closeText: 'Done',
//		ampm: false,
//		timeFormat: 'hh:mm tt',
//		timeOnlyTitle: 'Choose Time',
//		timeText: 'Time',
//		hourText: 'Hour',
//		minuteText: 'Minute',
//		secondText: 'Second'};
//	$j.timepicker.regional['pt'] = {//ToDo: Translate
//        currentText: 'Now',
//		closeText: 'Done',
//		ampm: false,
//		timeFormat: 'hh:mm tt',
//		timeOnlyTitle: 'Choose Time',
//		timeText: 'Time',
//		hourText: 'Hour',
//		minuteText: 'Minute',
//		secondText: 'Second'};
});
